#!/system/bin/sh
MODDIR=${0%/*}
setenforce <SELINUX_MODE>